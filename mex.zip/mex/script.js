// Elementi principali
const setupDiv = document.getElementById("setup");
const mainAppDiv = document.getElementById("mainApp");
const yourNameInput = document.getElementById("yourName");
const yourNumberInput = document.getElementById("yourNumber");
const saveNumberBtn = document.getElementById("saveNumberBtn");

const addContactBtn = document.getElementById("addContactBtn");
const addContactForm = document.getElementById("addContactForm");
const contactNameInput = document.getElementById("contactName");
const contactNumberInput = document.getElementById("contactNumber");
const saveContactBtn = document.getElementById("saveContactBtn");
const contactList = document.getElementById("contactList");

const chatHeader = document.getElementById("chatWith");
const messages = document.getElementById("messages");
const messageBox = document.getElementById("messageBox");
const sendBtn = document.getElementById("sendBtn");
const imageInput = document.getElementById("imageInput");

let yourInfo = {};
let contacts = [];
let activeChat = null;
const chatMessages = {};

// Configurazione iniziale
saveNumberBtn.onclick = () => {
    const name = yourNameInput.value.trim();
    const number = yourNumberInput.value.trim();

    if (!name || !number) {
        alert("Inserisci nome e numero!");
        return;
    }

    yourInfo = { name, number };
    setupDiv.classList.add("hidden");
    mainAppDiv.classList.remove("hidden");
};

// Aggiunta di nuovi contatti
addContactBtn.onclick = () => {
    addContactForm.classList.toggle("hidden");
};

saveContactBtn.onclick = () => {
    const name = contactNameInput.value.trim();
    const number = contactNumberInput.value.trim();

    if (!name || !number) {
        alert("Inserisci nome e numero del contatto!");
        return;
    }

    if (contacts.find((contact) => contact.number === number)) {
        alert("Contatto già esistente!");
        return;
    }

    contacts.push({ name, number });
    chatMessages[number] = [];
    updateContactList();

    contactNameInput.value = "";
    contactNumberInput.value = "";
    addContactForm.classList.add("hidden");
};

function updateContactList() {
    contactList.innerHTML = "";
    contacts.forEach((contact) => {
        const li = document.createElement("li");
        li.textContent = `${contact.name} (${contact.number})`;
        li.onclick = () => openChat(contact);
        contactList.appendChild(li);
    });
}

// Apri la chat con un contatto
function openChat(contact) {
    activeChat = contact;
    chatHeader.textContent = `Chat con ${contact.name}`;
    messageBox.removeAttribute("disabled");
    imageInput.removeAttribute("disabled");
    sendBtn.removeAttribute("disabled");

    renderMessages();
}

// Mostra i messaggi nella chat
function renderMessages() {
    messages.innerHTML = "";
    if (activeChat && chatMessages[activeChat.number]) {
        chatMessages[activeChat.number].forEach((msg) => appendMessage(msg.text, msg.image));
    }
}

// Invia un messaggio
sendBtn.onclick = () => {
    const text = messageBox.value.trim();
    const file = imageInput.files[0];

    if (!text && !file) return;

    const message = { text };

    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            message.image = e.target.result;
            saveMessage(message);
        };
        reader.readAsDataURL(file);
    } else {
        saveMessage(message);
    }

    messageBox.value = "";
    imageInput.value = "";
};

function saveMessage(message) {
    if (!activeChat) return;

    chatMessages[activeChat.number].push(message);
    appendMessage(message.text, message.image);
}

// Aggiungi un messaggio alla chat
function appendMessage(text, image) {
    const msgDiv = document.createElement("div");
    msgDiv.style.margin = "10px 0";

    if (text) {
        const textDiv = document.createElement("div");
        textDiv.textContent = text;
        msgDiv.appendChild(textDiv);
    }

    if (image) {
        const img = document.createElement("img");
        img.src = image;
        img.style.maxWidth = "100%";
        img.style.marginTop = "5px";
        msgDiv.appendChild(img);
    }

    messages.appendChild(msgDiv);
    messages.scrollTop = messages.scrollHeight;
}
